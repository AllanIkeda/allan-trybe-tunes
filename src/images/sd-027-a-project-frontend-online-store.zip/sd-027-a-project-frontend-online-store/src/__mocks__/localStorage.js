module.exports = [{
  email: 'test1@trybe.com',
  text: 'Avaliação do produto 1',
  rating: '5',
}, {
  email: 'test1@trybe.com',
  text: 'Avaliação do produto 2',
  rating: '4',
  }];
